a=10
a='python'
print(a)